const express = require("express");
const fetch = require("node-fetch");
const app = express();
const PORT = process.env.PORT || 3000;

const NOTION_TOKEN = "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";
const DATABASE_ID = "1dcf9c44ba3480a8a588ed3798bf94ca";

app.use(express.static("public"));

app.get("/api/balance", async (req, res) => {
  try {
    const response = await fetch("https://api.notion.com/v1/databases/" + DATABASE_ID + "/query", {
      method: "POST",
      headers: {
        "Authorization": "Bearer " + NOTION_TOKEN,
        "Content-Type": "application/json",
        "Notion-Version": "2022-06-28"
      }
    });

    const data = await response.json();
    const firstPage = data.results[0];
    const formula = firstPage.properties["Account Balance"].formula;
    const balance = formula && formula.number;

    res.json({ balance: balance });
  } catch (error) {
    console.error("Error fetching balance:", error);
    res.status(500).json({ error: "Failed to fetch balance" });
  }
});

app.listen(PORT, () => {
  console.log("Server running on port " + PORT);
});